---
name: Vigilance Sentinel
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#434655'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#00668a'
  on-secondary: '#ffffff'
  secondary-container: '#40c2fd'
  on-secondary-container: '#004d6a'
  tertiary: '#006242'
  on-tertiary: '#ffffff'
  tertiary-container: '#007d55'
  on-tertiary-container: '#bdffdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  metric-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.03em
  metric-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '700'
    lineHeight: 1.75rem
    letterSpacing: -0.02em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.025em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.05em
  mono-data:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-lg: 1.5rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system targets risk analysts, fraud operations managers, and fintech executives who demand real-time situational awareness without cognitive fatigue. The visual tone is surgical, ultra-modern, and reassuringly precise—channeling the spaciousness, rounded containers, and crisp hierarchy of modern collaborative analytics suites. 

The aesthetic merges contemporary corporate software with refined data visualization: pristine pure-white cards floating over an ultra-light slate foundation, high-contrast metric callouts, and surgical micro-indicators. The interface projects quiet authority, reliability, and instant legibility, allowing users to parse high-velocity transaction streams, anomaly spikes, and risk vectors in split seconds.

## Colors

The palette establishes an immediate optical hierarchy between neutral surveillance surfaces and high-urgency status signals:

- **Background Canvas (`#F8FAFC`):** Ultra-light cool slate foundation that reduces eye strain during prolonged monitoring sessions.
- **Card Surfaces (`#FFFFFF`):** High-purity white used for floating analytical cards, modals, and metric hubs.
- **Primary Electric Blue (`#2563EB`):** Primary interactions, selected tabs, key active filters, and primary metric emphasis.
- **Secondary Sky Blue (`#38BDF8`):** Data visualization comparison baselines, trend fills, range sliders, and active timeline scrubbers.
- **Emerald Green (`#10B981`):** Cleared transactions, approved authentications, and low-risk confidence scores.
- **Crimson Red (`#EF4444`):** Fraud attacks, compromised cards, chargebacks, and high-severity rule triggers.
- **Text & Structure:**
  - Headings and Key Metrics: Deep Slate (`#0F172A`)
  - Body Text & Secondary Metrics: Slate Core (`#334155`)
  - Form Placeholders & Micro Labels: Muted Slate (`#64748B`)
  - Subdued Borders & Grid Dividers: Slate Hairline (`#E2E8F0`)

## Typography

Plus Jakarta Sans powers the entire hierarchy to deliver clean, contemporary geometric clarity with high legibility across numerical readouts. 

- Metric values utilize tighter letter tracking (`-0.03em` to `-0.02em`) and heavier weights (`700`) to guarantee rapid optical parsing in dense dashboard views.
- Section headers, card labels, and chart axis labels make disciplined use of uppercase and semi-bold tokens (`label-sm`, `label-md`) with subtle positive letter spacing (`0.025em` to `0.05em`) to balance small font sizes.
- Tabular numeric displays and financial metrics require fixed numeric spacing (`font-variant-numeric: tabular-nums`) to prevent jitter during live data re-renders.

## Layout & Spacing

The dashboard employs a 12-column fluid grid system pinned inside a max-width container of `1600px`. 

- **Layout Structure:**
  - Sidebar navigation remains pinned at `260px` desktop width, collapsing into an icon-only strip (`72px`) on tablet breakpoints (`768px - 1024px`), and a bottom sheet or off-canvas drawer under `768px`.
  - Analytical cards snap to 3, 4, 6, or 12 columns depending on data density: single KPI cards span 3 columns, radial gauge summaries span 4 columns, and time-series multi-line charts span 8 to 12 columns.
- **Rhythm & Padding:**
  - Card internal padding defaults uniformly to `space-lg` (`1.5rem`) on desktop and steps down to `space-md` (`1rem`) on mobile.
  - Component element gaps (e.g., between metric value and badge indicator) strictly follow `space-xs` (4px) or `space-sm` (8px).

## Elevation & Depth

Visual separation relies on a combination of low-contrast hairline borders and soft ambient shadows rather than stark layered elevation:

- **Baseline Level (Background):** Pure matte cool slate (`#F8FAFC`) with no shadow.
- **Surface Level 1 (Analytical Cards & Tables):** Solid `#FFFFFF` background, a 1px structural border of `#E2E8F0`, and an ultra-diffused ambient shadow: `box-shadow: 0 4px 20px -2px rgba(15, 23, 42, 0.04), 0 2px 6px -1px rgba(15, 23, 42, 0.02)`.
- **Surface Level 2 (Hovered Cards & Dropdowns):** Subtle upward translation with an enhanced spread: `box-shadow: 0 10px 25px -3px rgba(15, 23, 42, 0.06), 0 4px 10px -2px rgba(15, 23, 42, 0.03)`.
- **Surface Level 3 (Alert Popovers & Modals):** `box-shadow: 0 20px 35px -5px rgba(15, 23, 42, 0.08), 0 10px 15px -4px rgba(15, 23, 42, 0.04)` combined with backdrop blur (`backdrop-filter: blur(8px)`) over `#0F172A` with `0.2` opacity.

## Shapes

The design system standardizes on generous, organic geometry to reinforce a friendly yet structured SaaS feel:

- **Containers & Cards:** Styled strictly with `16px` (`rounded-2xl` / `1rem`) corner radiuses, eliminating harsh angles.
- **Inputs & Standard Buttons:** Built with `8px` (`rounded-lg` / `0.5rem`) radius for focused ergonomics.
- **Status Badges, Segmentation Switches & Filter Chips:** Fully pill-shaped (`9999px`) to immediately distinguish interactive toggles and status markers from informational content blocks.

## Components

### Buttons
- **Primary:** Solid Electric Blue (`#2563EB`) fill, white text, 8px radius, height `40px` (desktop), with hover shifting to `#1D4ED8`. Active state scales subtly to `0.98`.
- **Secondary / Outlined:** `#FFFFFF` background, 1px border of `#E2E8F0`, `#0F172A` text, hovering to `#F8FAFC` with border `#CBD5E1`.
- **Destructive Action:** Solid Crimson Red (`#EF4444`) with white text, or 10% red tint background with pure red text for secondary destructive triggers.

### Micro Badges & Status Pills
- **Risk Level Badges:** Fully rounded (`9999px`), padding `2px 8px`, font size `11px`, weight `600`, tracking `0.05em`.
  - *Low Risk / Normal:* Background `#ECFDF5`, text `#059669`.
  - *Moderate Risk:* Background `#FEF3C7`, text `#D97706`.
  - *High Risk / Fraud:* Background `#FEF2F2`, text `#DC2626`.
- Includes a leading `6px` circular pulse dot indicating live status.

### Segmented Controls & Tabs
- Encapsulated pill wrapper with `#F1F5F9` background and `6px` interior padding.
- Selected segment features a clean white pill surface (`#FFFFFF`) with a micro-shadow (`0 1px 3px rgba(0,0,0,0.08)`), `#0F172A` text, and smooth slide animation.

### Cards & Analytical Panels
- Pure white background (`#FFFFFF`), `16px` border-radius, `1px solid #E2E8F0`, ambient shadow.
- Header region separates title and action triggers (timeframe selector or overflow icon) with a fixed line height, maintaining `1.5rem` internal margin.

### Data Visualizations
- **Radial Gauges:** Clean track in `#F1F5F9`, filled segment using `#2563EB` (normal) or `#EF4444` (critical thresholds), centered metric in `metric-xl` typography.
- **Sparklines & Charts:** Smooth cubic bezier curve rendering with stroke width `2.5px`. Gradients fade out vertically to 0% opacity at base. Zero-gridlines rendered in muted `#F1F5F9`.

### Data Tables & Transaction Logs
- Zero internal vertical borders. Row dividers rendered with 1px `#F1F5F9`.
- Header columns use `label-sm` with `#64748B` uppercase typography.
- Interactive rows transition to `#F8FAFC` on hover.

### Inputs & Filters
- Clean white background, 1px `#E2E8F0` border, `8px` corner radius, height `38px`. Focus state applies `#2563EB` border with a `3px` focus ring in `rgba(37, 99, 235, 0.15)`.